import type { CapacitorConfig } from "@capacitor/cli";
const config: CapacitorConfig = {
  appId: "app.animeheart.mobile",
  appName: "Anime Heart",
  webDir: "dist",
  bundledWebRuntime: false
};
export default config;