# Anime Heart 💕 — cross-platform starter

A responsive anime-discovery prototype that can run as a website/PWA-style frontend and be wrapped as an Android app with Capacitor.

## What is included
- Responsive dark-themed discovery interface
- Local demo catalogue with search and genre filters
- Favourites / My List saved in browser storage
- Detail view and official-provider directory
- Audio preference controls: Japanese, English, Tamil
- English subtitle preference
- Quality preference: Auto, 144p through 4K
- Legal-provider outbound links; no pirated streams or scraped video URLs

## Important limitations
This is a **starter prototype**, not a published or production streaming service. It does not contain video files, stream keys, provider contracts, accounts, payments, or a verified per-title availability feed. The language and quality selectors are preferences only; the actual provider player controls what is available for each title. The demo title list is intentionally small. Season completeness and region-specific rights must be checked against each licensed provider before displaying them as available.

The free options in the provider directory are official publisher channels; individual videos can be region-restricted and the catalogue can change. Paid providers may require a subscription. No service is represented as universally free.

## Run the website locally
Requires Node.js 20 or newer.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite.

## Build the website
```bash
npm run build
npm run preview
```
Deploy the generated `dist/` directory to a static hosting provider that supports HTTPS.

## Build the Android wrapper
Install Android Studio and the Android SDK first.

```bash
npm install
npx cap add android
npm run android:sync
npm run android:open
```

In Android Studio, select an emulator or connected test device and run the app. For a release APK/AAB, configure your own signing key in Android Studio and follow Google's current Play Console requirements.

## Before production release
1. Replace the demo catalogue with a properly licensed metadata source and comply with its API terms.
2. Sign agreements with distributors/platforms if you want in-app playback. Otherwise keep official provider deep-links.
3. Add a backend for user accounts, watch progress sync, parental/content ratings, analytics consent, and secure configuration.
4. Implement per-title, per-season, per-episode availability with territory, audio tracks, subtitle tracks, and quality metadata supplied by licensors.
5. Add a privacy policy, terms, copyright/takedown process, accessibility checks, and app-store compliance.
6. Test on real Android devices and multiple browsers.

## Provider links
The app links to official provider home/channel pages. It does not claim that any specific anime is currently available on a given service. Confirm rights, territory, dub/sub tracks, and free/ad-supported status on the provider's own title page.

## Project structure
- `src/main.jsx` — app UI and demo data
- `src/styles.css` — responsive styling
- `capacitor.config.ts` — Android wrapper configuration
- `index.html` — web entry point


## News and episode schedule update
The News tab links to established anime news publishers. It does not scrape or republish headlines. Next-episode dates are looked up through AniList's public GraphQL API when an airing schedule is published and are formatted in the device's local time zone. Some titles will have no upcoming episode, release dates can change, and API access is not guaranteed. A production in-app news feed should use a licensed RSS/API integration.


## Build an APK using GitHub Actions from an Android phone

This project includes `.github/workflows/android-apk.yml`. GitHub's cloud runner builds a debug APK, so Android Studio is not needed on your phone.

1. Upload the contents of this `anime-heart` folder to the root of your GitHub repository (upload the files, not the ZIP itself).
2. Open the repository's **Actions** tab and select **Build Anime Heart APK**.
3. Tap **Run workflow** and confirm.
4. When the run completes successfully, open it and download the `anime-heart-debug-apk` artifact.
5. Extract the artifact ZIP on your phone, then open `app-debug.apk` to install it. Android may ask you to allow installs from the browser or file manager you used.

The APK is a debug build for personal testing, not a Play Store release package.

## Manga page

The Manga tab is a discovery page with sample titles and links to publisher platforms. It does not host chapter scans or provide a built-in reader. Use authorized platforms for manga chapters.
