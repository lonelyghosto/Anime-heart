import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import { Search, Heart, Play, SlidersHorizontal, Sparkles, MonitorPlay, Languages, ChevronRight, X, Menu, Bookmark, Info } from "lucide-react";
import "./styles.css";

const anime = [
  { id: 1, title: "Frieren: Beyond Journey's End", genre: "Fantasy", year: 2023, seasons: "Season information varies by provider", description: "A thoughtful fantasy journey that begins after the hero's party has already saved the world.", tags: ["Fantasy", "Adventure"], accent: "lavender", poster: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&q=80" },
  { id: 2, title: "Spy x Family", genre: "Comedy", year: 2022, seasons: "Multiple parts; check provider listing", description: "A spy, an assassin and a telepath form an unusual pretend family.", tags: ["Comedy", "Action"], accent: "pink", poster: "https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=600&q=80" },
  { id: 3, title: "Haikyu!!", genre: "Sports", year: 2014, seasons: "Multiple seasons; check provider listing", description: "A determined volleyball player works toward his dream with his team.", tags: ["Sports", "Comedy"], accent: "orange", poster: "https://images.unsplash.com/photo-1519861531473-9200262188bf?w=600&q=80" },
  { id: 4, title: "My Hero Academia", genre: "Action", year: 2016, seasons: "Multiple seasons; check provider listing", description: "A student works hard to become a hero in a world where superpowers are common.", tags: ["Action", "Adventure"], accent: "blue", poster: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?w=600&q=80" },
  { id: 5, title: "A Place Further Than the Universe", genre: "Adventure", year: 2018, seasons: "1 season listed; verify provider catalogue", description: "Four high-school friends set out on an extraordinary journey to Antarctica.", tags: ["Adventure", "Drama"], accent: "teal", poster: "https://images.unsplash.com/photo-1470770841072-f978cf4d019e?w=600&q=80" },
  { id: 6, title: "Your Lie in April", genre: "Drama", year: 2014, seasons: "1 season listed; verify provider catalogue", description: "Two young musicians discover new inspiration through music and friendship.", tags: ["Drama", "Music"], accent: "rose", poster: "https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=600&q=80" },
  { id: 7, title: "Dr. STONE", genre: "Adventure", year: 2019, seasons: "Multiple seasons; check provider listing", description: "A science-minded student tries to rebuild civilization after a mysterious event.", tags: ["Adventure", "Science"], accent: "green", poster: "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=600&q=80" },
  { id: 8, title: "K-On!", genre: "Comedy", year: 2009, seasons: "2 seasons listed; verify provider catalogue", description: "Friends build a school music club and make memories together.", tags: ["Comedy", "Music"], accent: "yellow", poster: "https://images.unsplash.com/photo-1516280440614-37939bbacd81?w=600&q=80" }
];

// Public airing metadata lookup. Dates appear only when a schedule is published.
const ANILIST_ENDPOINT = "https://graphql.anilist.co";
const NEWS_SOURCES = [
  { name: "Anime News Network", note: "Industry news, announcements and release coverage", url: "https://www.animenewsnetwork.com/" },
  { name: "Crunchyroll News", note: "Anime announcements, trailers and seasonal updates", url: "https://www.crunchyroll.com/news" },
  { name: "Anime Corner", note: "Seasonal anime news and release coverage", url: "https://animecorner.me/" }
];
async function fetchAiringSchedule(searchTitle) {
  const query = `query ($search: String) { Media(search: $search, type: ANIME) { id title { romaji english native } nextAiringEpisode { airingAt episode } siteUrl } }`;
  const response = await fetch(ANILIST_ENDPOINT, {
    method: "POST", headers: { "Content-Type": "application/json", "Accept": "application/json" },
    body: JSON.stringify({ query, variables: { search: searchTitle } })
  });
  if (!response.ok) throw new Error("Schedule unavailable");
  const result = await response.json();
  return result?.data?.Media || null;
}
function formatRelease(airingAt) {
  if (!airingAt) return null;
  return new Intl.DateTimeFormat(undefined, { dateStyle: "medium", timeStyle: "short",
    timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone }).format(new Date(airingAt * 1000));
}

const providers = [
  { name: "Muse Asia", note: "Official YouTube publisher; selected free titles and regions", url: "https://www.youtube.com/@MuseAsia", free: true },
  { name: "Ani-One Asia", note: "Official YouTube publisher; availability and membership vary", url: "https://www.youtube.com/@AniOneAsia", free: true },
  { name: "Crunchyroll", note: "Licensed anime catalogue; plan and title availability vary", url: "https://www.crunchyroll.com/", free: false },
  { name: "Netflix", note: "Licensed catalogue; subscription and regional availability vary", url: "https://www.netflix.com/", free: false },
  { name: "JioHotstar", note: "Regional catalogue; plan and title availability vary", url: "https://www.jiohotstar.com/", free: false },
  { name: "Prime Video", note: "Licensed titles and add-on channels may require payment", url: "https://www.primevideo.com/", free: false }
];

function App() {
  const [query, setQuery] = useState("");
  const [genre, setGenre] = useState("All");
  const [tab, setTab] = useState("Discover");
  const [selected, setSelected] = useState(null);
  const [favorites, setFavorites] = useState(() => JSON.parse(localStorage.getItem("ah-favorites") || "[]"));
  const [audio, setAudio] = useState("Japanese");
  const [subs, setSubs] = useState("English");
  const [quality, setQuality] = useState("Auto");
  const [showProviders, setShowProviders] = useState(false);
  const [airingData, setAiringData] = useState({});
  const [airingLoading, setAiringLoading] = useState({});
  const [airingErrors, setAiringErrors] = useState({});

  const visible = useMemo(() => anime.filter(a => {
    const matchesText = `${a.title} ${a.genre} ${a.tags.join(" ")}`.toLowerCase().includes(query.toLowerCase());
    const matchesGenre = genre === "All" || a.tags.includes(genre);
    const matchesTab = tab !== "My List" || favorites.includes(a.id);
    return matchesText && matchesGenre && matchesTab;
  }), [query, genre, tab, favorites]);

  async function loadAiring(title, id) {
    if (airingData[id] || airingLoading[id]) return;
    setAiringLoading(prev => ({ ...prev, [id]: true }));
    setAiringErrors(prev => ({ ...prev, [id]: "" }));
    try {
      const result = await fetchAiringSchedule(title);
      setAiringData(prev => ({ ...prev, [id]: result }));
    } catch {
      setAiringErrors(prev => ({ ...prev, [id]: "Schedule could not be loaded right now." }));
    } finally {
      setAiringLoading(prev => ({ ...prev, [id]: false }));
    }
  }

  useEffect(() => {
    // Populate next-episode dates beneath catalogue cards where public schedule data exists.
    anime.forEach(item => loadAiring(item.title, item.id));
  }, []);

  function toggleFavorite(id) {
    const next = favorites.includes(id) ? favorites.filter(x => x !== id) : [...favorites, id];
    setFavorites(next);
    localStorage.setItem("ah-favorites", JSON.stringify(next));
  }

  return <div className="app-shell">
    <header className="topbar">
      <a className="brand" href="#" onClick={() => {setTab("Discover"); setSelected(null);}}>
        <span className="brand-mark">♡</span><span>anime <b>heart</b> <i>💕</i></span>
      </a>
      <nav className="desktop-nav">
        {["Discover", "News", "Manga", "My List", "Providers"].map(t => <button key={t} className={tab === t ? "nav-link active" : "nav-link"} onClick={() => {setTab(t); setSelected(null); if(t==="Providers") setShowProviders(true);}}>{t}</button>)}
      </nav>
      <span className="top-note"><span className="live-dot"></span> Discover • Watch legally</span>
    </header>

    <main>
      <section className="hero">
        <div className="hero-copy">
          <div className="eyebrow"><Sparkles size={14}/> YOUR NEXT ANIME OBSESSION</div>
          <h1>Stories that<br/><span>stay with you.</span></h1>
          <p>Discover new worlds, save your favourites, and find official places to watch.</p>
          <button className="primary-btn" onClick={() => document.getElementById("catalogue")?.scrollIntoView({behavior:"smooth"})}>Explore anime <ChevronRight size={17}/></button>
        </div>
        <div className="hero-art" aria-label="Abstract anime-inspired artwork">
          <div className="orb orb-one"></div><div className="orb orb-two"></div><div className="hero-spark">✦</div>
          <div className="hero-card"><span>ANIME HEART</span><strong>Find your<br/>next story.</strong><small>DISCOVER • SAVE • WATCH</small></div>
        </div>
      </section>

      <section className="quick-stats">
        <div><strong>{anime.length.toString().padStart(2,"0")}</strong><span>Demo titles</span></div>
        <div><strong>03</strong><span>Audio preferences</span></div>
        <div><strong>06</strong><span>Provider links</span></div>
        <div><strong>♡</strong><span>Your watchlist</span></div>
      </section>

      <section className={tab === "News" || tab === "Manga" ? "catalogue hidden" : "catalogue"} id="catalogue">
        <div className="section-heading">
          <div><div className="eyebrow">THE COLLECTION</div><h2>{tab === "My List" ? "Your watchlist" : "Find your anime"}</h2></div>
          <div className="search-box"><Search size={18}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search titles or genres..." aria-label="Search anime"/></div>
        </div>
        <div className="filter-row">
          <div className="genre-pills">{["All","Action","Adventure","Comedy","Drama","Fantasy","Sports","Music"].map(g=><button key={g} onClick={()=>setGenre(g)} className={genre===g?"pill selected":"pill"}>{g}</button>)}</div>
          <button className="filter-btn" onClick={()=>setShowProviders(true)}><SlidersHorizontal size={15}/> Watch options</button>
        </div>
        {visible.length ? <div className="anime-grid">{visible.map((a,i)=><article className="anime-card" key={a.id}>
          <button className={`poster poster-${a.accent}`} onClick={()=>setSelected(a)} aria-label={`View ${a.title}`}>
            <div className="poster-graphic"><span className="poster-symbol">{["✦","♡","◉","✧","☼","♫","✺","♪"][i%8]}</span><span className="poster-title">{a.title}</span><small>{a.year} · {a.genre.toUpperCase()}</small></div>
            <span className="poster-open"><Play size={16} fill="currentColor"/></span>
          </button>
          <div className="card-meta"><div><h3>{a.title}</h3><p>{a.year} <span>•</span> {a.genre}</p></div><button className={favorites.includes(a.id)?"heart-btn saved":"heart-btn"} onClick={()=>toggleFavorite(a.id)} aria-label="Toggle favourite"><Heart size={18} fill={favorites.includes(a.id)?"currentColor":"none"}/></button></div>
          <div className="release-line"><span className="release-label">NEXT EPISODE</span>
            <strong>{airingLoading[a.id] ? "Checking schedule…" : airingData[a.id]?.nextAiringEpisode ? `Ep ${airingData[a.id].nextAiringEpisode.episode} · ${formatRelease(airingData[a.id].nextAiringEpisode.airingAt)}` : airingErrors[a.id] || "Check schedule in details"}</strong></div>
          <button className="details-link" onClick={()=>{setSelected(a); loadAiring(a.title, a.id);}}>Details & release info <ChevronRight size={14}/></button>
        </article>)}</div> : <div className="empty-state"><Heart size={28}/><h3>No titles found</h3><p>Try another search or genre.</p></div>}
      </section>


      {tab === "Manga" && <section className="manga-section">
        <div className="eyebrow">READ THROUGH OFFICIAL SOURCES</div>
        <h2>Manga library</h2>
        <p className="muted">Discover manga and open an official publisher or reading platform. Availability, chapters and languages vary by region.</p>
        <div className="manga-grid">
          {[
            ["One Piece", "Adventure", "MANGA Plus", "https://mangaplus.shueisha.co.jp/"],
            ["SPY x FAMILY", "Comedy", "MANGA Plus", "https://mangaplus.shueisha.co.jp/"],
            ["Blue Lock", "Sports", "Kodansha", "https://kodansha.us/"],
            ["Frieren: Beyond Journey's End", "Fantasy", "VIZ", "https://www.viz.com/"],
            ["My Hero Academia", "Action", "MANGA Plus", "https://mangaplus.shueisha.co.jp/"],
            ["Haikyu!!", "Sports", "VIZ", "https://www.viz.com/"]
          ].map((m, i) => <article className="manga-card" key={m[0]}>
            <div className={`manga-cover manga-cover-${i % 6}`}><span>♡</span><strong>{m[0]}</strong><small>{m[1]}</small></div>
            <div className="manga-card-copy"><h3>{m[0]}</h3><p>{m[1]} manga</p>
              <a href={m[3]} target="_blank" rel="noreferrer">Find on {m[2]} <ChevronRight size={14}/></a>
            </div>
          </article>)}
        </div>
        <p className="manga-note"><Info size={15}/> This is a discovery page, not a built-in manga reader. Anime Heart does not host manga chapters; use authorized publisher platforms.</p>
      </section>}

      {tab === "News" && <section className="news-section">
        <div className="eyebrow">WHAT'S HAPPENING IN ANIME</div><h2>Anime news & release updates</h2>
        <p className="muted">Follow announcements, new episodes, movie premieres and seasonal updates from established sources.</p>
        <div className="news-feature"><div className="news-icon">✦</div><div><span className="news-kicker">RELEASE TRACKER</span><h3>Upcoming episode dates</h3>
        <p>Episode dates and times are fetched from AniList when a title has a published airing schedule. Times are displayed in your device's local time zone.</p></div></div>
        <div className="news-source-grid">{NEWS_SOURCES.map(source => <a className="news-source" key={source.name} href={source.url} target="_blank" rel="noreferrer"><span><b>{source.name}</b><small>{source.note}</small></span><ChevronRight size={17}/></a>)}</div>
        <div className="news-disclaimer"><Info size={15}/> News links open publishers' sites; this prototype does not scrape or invent headlines. A production in-app feed needs a licensed RSS/API integration.</div>
      </section>}

      <section className="watch-settings">
        <div className="settings-copy"><div className="eyebrow">MAKE IT YOURS</div><h2>Your viewing preferences</h2><p>Choose your preferred settings. Actual options depend on the licensed stream you open.</p></div>
        <div className="settings-controls">
          <label><span><Languages size={15}/> Audio language</span><select value={audio} onChange={e=>setAudio(e.target.value)}><option>Japanese</option><option>English</option><option>Tamil</option></select></label>
          <label><span>CC Subtitles</span><select value={subs} onChange={e=>setSubs(e.target.value)}><option>English</option><option>Off</option></select></label>
          <label><span><MonitorPlay size={15}/> Video quality</span><select value={quality} onChange={e=>setQuality(e.target.value)}>{["Auto","144p","240p","360p","480p","720p","1080p","4K"].map(q=><option key={q}>{q}</option>)}</select></label>
        </div>
        <p className="settings-footnote"><Info size={14}/> These are saved preferences for the app interface—not a promise that a provider offers every language or resolution.</p>
      </section>

      <section className="providers-section">
        <div><div className="eyebrow">OFFICIAL SOURCES ONLY</div><h2>Where to watch</h2><p>Free and subscription services. A title may not be available in every country or language.</p></div>
        <button className="text-btn" onClick={()=>setShowProviders(true)}>View providers <ChevronRight size={15}/></button>
      </section>
    </main>

    <footer><div className="brand"><span className="brand-mark">♡</span><span>anime <b>heart</b> 💕</span></div><p>Fan-made discovery prototype. Not affiliated with anime studios or streaming services.</p><p>Only watch through official, licensed providers.</p></footer>

    {selected && <div className="modal-backdrop" onClick={()=>setSelected(null)}><div className="detail-modal" onClick={e=>e.stopPropagation()}>
      <button className="close-btn" onClick={()=>setSelected(null)}><X size={20}/></button>
      <div className={`detail-art poster-${selected.accent}`}><span>{selected.title}</span></div>
      <div className="detail-content"><div className="eyebrow">ANIME DETAILS</div><h2>{selected.title}</h2><p className="detail-sub">{selected.year} · {selected.genre}</p><p>{selected.description}</p><div className="season-note"><Bookmark size={16}/>{selected.seasons}</div>
        <div className="detail-release"><b>Next episode</b>
          {airingLoading[selected.id] ? <span>Checking published schedule…</span> :
           airingData[selected.id]?.nextAiringEpisode ? <span>Episode {airingData[selected.id].nextAiringEpisode.episode} · {formatRelease(airingData[selected.id].nextAiringEpisode.airingAt)}</span> :
           <span>{airingErrors[selected.id] || "No upcoming episode date currently published."}</span>}
          <button onClick={()=>{setAiringData(prev=>({...prev,[selected.id]:null})); setAiringErrors(prev=>({...prev,[selected.id]:""})); loadAiring(selected.title, selected.id);}}>Refresh schedule</button>
        </div>
        <h3>Find an official stream</h3><p className="muted">We do not host episodes. Choose a provider and check its current regional listing.</p>
        <div className="provider-mini">{providers.map(p=><a key={p.name} href={p.url} target="_blank" rel="noreferrer"><span>{p.name}<small>{p.free?"Free selection":"Subscription / paid selection"}</small></span><ChevronRight size={16}/></a>)}</div>
        <button className="secondary-btn" onClick={()=>toggleFavorite(selected.id)}>{favorites.includes(selected.id)?"Remove from My List":"♡ Add to My List"}</button>
      </div>
    </div></div>}

    {showProviders && <div className="modal-backdrop" onClick={()=>setShowProviders(false)}><div className="providers-modal" onClick={e=>e.stopPropagation()}>
      <button className="close-btn" onClick={()=>setShowProviders(false)}><X size={20}/></button><div className="eyebrow">LEGAL WATCHING</div><h2>Official providers</h2><p className="muted">Free availability, regional rights, dubs, subtitles and quality vary by title.</p>
      {providers.map(p=><a className="provider-row" key={p.name} href={p.url} target="_blank" rel="noreferrer"><span><b>{p.name}</b><small>{p.note}</small></span><span className={p.free?"free-tag":"paid-tag"}>{p.free?"Free selection":"Paid / mixed"} ↗</span></a>)}
    </div></div>}
  </div>;
}

createRoot(document.getElementById("root")).render(<App/>);